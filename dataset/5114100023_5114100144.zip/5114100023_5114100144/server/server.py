#!/usr/bin/env python 

""" 
An echo server that uses threads to handle multiple clients at a time. 
Entering any line of input at the terminal will exit the server. 
""" 

import select 
import socket 
import sys 
import threading
import datetime
import time

counter = 0
counter_str = ""
clients = []
threads = []
messages = []

class Server: 
    def __init__(self): 
        self.host = '' 
        self.port = 50012
        self.backlog = 5
        self.size = 1024 
        self.server = None 
        self.threads = [] 

    def open_socket(self): 
        try: 
            self.server = socket.socket(socket.AF_INET, socket.SOCK_STREAM) 
            self.server.bind((self.host,self.port)) 
            self.server.listen(1) 
        except socket.error, (value,message): 
            if self.server: 
                self.server.close() 
            print "Could not open socket: " + message 
            sys.exit(1) 

    def run(self): 
        self.open_socket() 
        input = [self.server,sys.stdin]
        running = 1 
        while running: 
            inputready,outputready,exceptready = select.select(input,[],[])

            for s in inputready: 

                if s == self.server: 
                    # handle the server socket 
                    c = Client(self.server.accept())
                    c.start() 
                    self.threads.append(c) 

                elif s == sys.stdin: 
                    # handle standard input 
                    junk = sys.stdin.readline() 
                    running = 0 

        # close all threads 

        self.server.close() 
        for c in self.threads:
            c.join() 

def broadcast(client,messages):
    message_str = ""
    for message in messages:
        message_str += message + '\n'
    client.send(message_str)
    time.sleep(1)

class Client(threading.Thread): 
    def __init__(self,(client,address)):
        threading.Thread.__init__(self) 
        self.client = client
        self.address = address 
        self.size = 128
        global clients
        clients.append(client)

    def run(self): 
        running = 1 
        while running:
            
            ############################################################

            client_id = self.client.recv(self.size)
            
            # terima perintah
            inputan = self.client.recv(self.size)

            # menerima file
            if (inputan[:6] == 'upload'):

                # ambil nama file
                path = inputan.split('upload ',1)[1]

                # header ukuran
                filesize = self.client.recv(self.size)

                if filesize != "":
                    # isi file
                    isi_file = self.client.recv(self.size)
                    f = open('temp/' + path, 'wb+')
                    f2 = open('../client/rcvd/' + path, 'wb+')
                    while(isi_file):
                         f.write(isi_file)
                         f2.write(isi_file)
                         isi_file = self.client.recv(self.size)
                    f.close()
                    f2.close()



                message = '<Mengirim ' + path + '>. Tersimpan'

            # menerima teks
            else :

                message = inputan
            
            # self.client.close()
            message = client_id + ' ('+ str(datetime.datetime.now()).split('.')[0] + ') : ' + message
            messages.append(message)

            for client in clients :
                if client != self.client :
                    t = threading.Thread(target=broadcast(client,messages))
                    threads.append(t)
                    t.start()

            running = 0

            ###########################################################

if __name__ == "__main__": 
    s = Server()
    s.run()
