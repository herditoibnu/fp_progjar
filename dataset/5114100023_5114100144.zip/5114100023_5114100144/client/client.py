#!/usr/bin/env python

import socket
import sys
import os
import time
import select

host = 'localhost'
port = 50012
size = 1024

available_extension = '.html.mp3.ogv.png.txt'

s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
s.connect((host, port))

sys.stdout.write("Masukkan nama : ")
client_name = sys.stdin.readline().replace("\n", "")
s.send(client_name)
time.sleep(1)

input_socket = [0, s]

while 1:

    inputready, outputready, exceptready = select.select(input_socket, [], [])

    for object in inputready :

        if object == s :

            message = s.recv(size)
            print message

        elif object == 0 :

            sys.stdout.write('% ')

            # ambil input
            inputan = sys.stdin.readline().replace("\n", "")

            # mengirim file
            if(inputan[:6] == 'upload'):

                 try:
                     # harus ada titik (.)
                     if '.' in inputan:

                         # ambil ekstensi file
                         extension = os.path.splitext(inputan.split('upload ')[1].replace('\n',''))[1]

                         # ekstensi file harus sesuai
                         if extension.lower() in available_extension:

                             # perintah
                             s.send(inputan)
                             time.sleep(1)

                             # ambil nama file
                             path = inputan.split('upload ',1)[1]
                             path = 'dataset/' + path

                             # header
                             filesize = 'file-size: ' + str(os.path.getsize(path)) + ','
                             s.send(filesize)
                             time.sleep(1)

                             # buka file
                             f = open(path, 'rb')

                             # kirim file
                             isi_file = f.read()
                             s.send(isi_file)
                             time.sleep(1)

                             # tutup file
                             f.close()

                         else:
                             print 'ekstensi file bukan .html .mp3 .ogv .png .txt'
                     else:
                         print 'file tidak memiliki ekstensi'
                 except KeyboardInterrupt:
                     s.close()
                     sys.exit(0)
                 except Exception as msg:
                     print msg

            # mengirim teks
            else:

                 s.send(inputan)
                 time.sleep(1)